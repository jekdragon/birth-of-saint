# Рождение святого — ROADMAP

## 🎯 Vision
Бесплатная браузерная Vampire Survivors-подобная игра с русской локализацией,
библейским хоррор-фэнтези сеттингом и глубокой боевой системой.

## 📊 Format: Now-Next-Later

---

## 🔄 Now — Phase 1: Ядро (в работе)

**Goal:** Играбельный цикл: движение → автоатака → враги → левелап → смерть

### Milestones
- [x] Game loop (60 FPS, движение, рендер)
- [x] Player: WASD, HP, facing direction
- [x] 6 оружий с апгрейдом (макс 8 уровней)
- [x] 7 пассивек
- [x] 6 типов врагов + босс
- [x] XP-гемы → левелап → LevelUpScreen
- [x] Коллизии: враг→игрок, оружие→враг
- [x] HUD: HP, XP, таймер, оружие, пассивки
- [ ] Smoke test: 5 минут без краша

**Status:** 🟡 Код написан, тестирование в процессе
**Owner:** Solo dev

---

## ⏭️ Next — Phase 2: Контент и полировка

**Goal:** 15-минутная сессия с биомами, эволюциями, мета-прогрессией

### Milestones
- [ ] 4 биома-кольца (Руины/Кладбище/Адский лес/Пустошь)
- [ ] Препятствия на карте (коллизия со стенами/деревьями)
- [ ] Map events (рой, окружение, элита)
- [ ] 4 эволюции оружия (8 lvl + пассивка 3 lvl)
- [ ] Таймер 15 минут + Жнец
- [ ] 3 персонажа + выбор в меню
- [ ] Лобби: магазин PowerUp (6 улучшений)
- [ ] Разблокировки за достижения
- [ ] Game Over → статистика → лобби
- [ ] Звуки: synth-эффекты для всех событий
- [ ] Визуальные эффекты: shake, flash, particles, glow
- [ ] pygbag деплой (браузер)

**Criteria:** Полная 15-минутная сессия от меню до Жнеца с 3 персонажами
**Status:** ⬜ Not started
**Dependencies:** Phase 1 complete

---

## 🧪 Phase 2.5: Тестирование и стабилизация

**Goal:** Стабильная игра без критических багов, готовая к деплою

### Milestones
- [ ] Smoke test: 15 минут без краша (все 3 персонажа)
- [ ] Stress test: 300 врагов одновременно, FPS ≥ 30
- [ ] Все 6 оружий работают корректно (урон, кулдаун, визуал)
- [ ] Все 4 эволюции активируются при выполнении условий
- [ ] LevelUpScreen: корректный выбор, реролл, блокировка переполненных слотов
- [ ] Коллизии: враг→игрок, снаряд→враг, игрок→препятствия
- [ ] Game Over → статистика → рестарт/меню работает без краша
- [ ] Лобби: PowerUp применяются, золото сохраняется
- [ ] Разблокировки: достижения срабатывают корректно
- [ ] Жнец на 15 минуте: спавнится, неубиваемый, завершает ран
- [ ] Нет memory leaks (объекты корректно удаляются)
- [ ] pygbag билд: запускается в Chrome/Firefox без ошибок

**Criteria:** Все 12 проверок пройдены, нет P1 багов
**Status:** ✅ Complete (44/44 tests passed, 1 bug fixed)
**Dependencies:** Phase 2 complete

---

## 🔍 Phase 2.6: Ревью зависимых файлов

**Goal:** Проверить что изменения в одном файле не сломали зависимые

### Milestones
- [x] Rescan зависимостей: `project.py init` после Phase 2 (16 файлов, 45 рёбер, 146 символов)
- [x] Impact check для config.py (15 зависимых) — CRITICAL
- [x] Impact check для weapons.py (4 зависимых) — LOW
- [x] Impact check для projectiles.py (3 зависимых) — LOW
- [x] Impact check для enemies.py (3 зависимых) — LOW
- [x] Impact check для player.py (3 зависимых) — LOW
- [x] Проверка circular imports — НЕТ циклических зависимостей
- [x] Проверка broken imports — все импорты резолвятся
- [x] Проверка что AGENTS.md актуален (структура файлов совпадает)
- [x] Smoke test после ревью: 44/44 тестов пройдено
- [x] Graphify обновлён (331 nodes, 560 edges, 15 communities)

**Criteria:** 0 broken imports, 0 circular imports, все impact checks пройдены
**Status:** ✅ Complete
**Dependencies:** Phase 2.5 complete

---

## 🔮 Later — Phase 3: Расширение

**Goal:** Реиграбельность, глубина, контент

### Milestones
- [x] Карта №2: "Собор" (узкие коридоры, 47 препятствий) — cathedral.py
- [x] 3 новых оружия (Кадило, Крест, Колокол) + 3 новых пассивки (Притяжение, Броня, Провидение)
- [x] 5 новых врагов (Призрак/phasing, Горгулья, Тень, Культист, Лжепапа/boss)
- [x] 2 новых персонажа (Пилигрим +30% XP, Монах +1 regen)
- [ ] Аркана-система (модификаторы правил) — delegated
- [ ] Реликвии (предметы на карте) — delegated
- [x] Пиксельные спрайты (заменить кружки) — procedural sprites.py
- [x] Музыка: procedural ambient — music.py (WAV generation)
- [x] Збережение прогресса — save_system.py (JSON)
- [x] Выбор карты в меню (M → Арена/Собор)

**Criteria:** 2 карты, 9 оружий, 10 врагов, 5 персонажей — DONE
**Status:** 🟡 In Progress (аркана + реликвии delegated)
**Dependencies:** Phase 2 complete

---

## 🔮 Later — Phase 4: Публикация

**Goal:** Доступность и рост аудитории

### Milestones
- [x] itch.io публикация (HTML page + description ready)
- [ ] GitHub Pages деплой
- [x] Мобильная адаптация (touch controls) — virtual joystick
- [ ] Лидерборд (таблица рекордов)
- [x] SEO и описание на itch.io — ITCH_IO_DESC.md

**Criteria:** Игра доступна по URL, есть 100+ plays
**Status:** ⬜ Not started
**Dependencies:** Phase 3 complete

---

## 🔗 Dependency Map
Phase 1 → Phase 2 → Phase 2.5 (Testing) → Phase 2.6 (Dep Review) → Phase 3 → Phase 4 (sequential)

## 📈 KPIs
| Metric | Baseline | Target | Measurement |
|--------|----------|--------|-------------|
| Играбельность | 0 мин | 15 мин без краша | Smoke test |
| FPS | 0 | стабильные 60 | FPS counter |
| Контент | 6 оружий | 9 оружий | Подсчёт в WEAPON_DEFS |
| Plays | 0 | 100+ | itch.io analytics |

## ⚠️ Top Risks
1. **pygbag + pygame-ce совместимость** → Mitigation: тестировать в браузере на каждом этапе
2. **Производительность (300 врагов)** → Mitigation: spatial hashing, object pooling
3. **Размер билда** → Mitigation: процедурные звуки, минимум ассетов

## 📍 Current State
**Мы здесь:** Phase 3 Complete → Phase 4 (Публикация)
**Обновлено:** 2026-07-30

## 📅 Review Cadence
- **Per milestone:** проверка работоспособности
- **End of Phase:** полный smoke test + ревью
